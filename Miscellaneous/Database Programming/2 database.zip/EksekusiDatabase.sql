drop database if exists dbPenjualanBarang;

create database dbPenjualanBarang;

use dbPenjualanBarang;

create table tblBarang
(
kdbarang varchar(30) primary key,
namabarang varchar(150),
minimum int,
jumlahstok int,
satuan varchar(20),
hargadasar double
);


create table tblPelanggan
(
kdpel varchar(50) primary key,
namapel varchar(100),
tgllahir timestamp,
jkelamin varchar(10),
pekerjaan varchar(30)
);

create table tblTransaksi
(
notrans varchar(30) primary key,
tanggal timestamp,
kdpel varchar(50),
foreign key (kdpel) references tblPelanggan(kdpel)
);

create table tblRinciTransaksi
(
notrans varchar(30),
kdbarang varchar(30),
harga double,
jumlah int,
foreign key (notrans) references tblTransaksi(notrans) on delete cascade on update cascade,
foreign key (kdbarang) references tblBarang(kdbarang) on delete cascade on update cascade
);

LOAD DATA LOCAL INFILE 'tblBarang.CSV'
INTO TABLE tblBarang
FIELDS TERMINATED BY ';'
ENCLOSED BY ''''
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'tblPelanggan.CSV'
INTO TABLE tblPelanggan
FIELDS TERMINATED BY ';'
ENCLOSED BY ''''
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'tblNotaTransaksi.CSV'
INTO TABLE tblTransaksi
FIELDS TERMINATED BY ';'
ENCLOSED BY ''''
IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'tblRinciTransaksi.CSV'
INTO TABLE tblRinciTransaksi
FIELDS TERMINATED BY ';'
ENCLOSED BY ''''
IGNORE 1 LINES;