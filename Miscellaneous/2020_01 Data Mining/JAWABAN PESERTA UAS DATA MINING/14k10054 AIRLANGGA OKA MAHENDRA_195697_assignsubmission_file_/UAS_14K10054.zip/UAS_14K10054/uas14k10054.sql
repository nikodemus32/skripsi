DROP DATABASE IF EXISTS dbUAS14K10054;
CREATE DATABASE dbUAS14K10054;
USE dbUAS14K10054;

CREATE TABLE tblUAS14K10054
(
  nopasien VARCHAR(10),
  demam VARCHAR(10),
  sakitkepala VARCHAR(10),
  nyeri VARCHAR(10),
  lemas VARCHAR(10),
  kelelahan VARCHAR(10),
  hidungtersumbat VARCHAR(10),
  bersin VARCHAR(10),
  sakittenggorokan VARCHAR(10),
  sulitbernafas VARCHAR(10),
  diagnosa VARCHAR(10)
);

LOAD DATA LOCAL INFILE '14k10054.csv'
INTO TABLE tblUAS14K10054
FIELDS TERMINATED BY ','
ENCLOSED BY ''''
IGNORE 1 LINES;

SELECT * FROM tblUAS14K10054;

/*LANGKAH 2: buat tabel untuk menampung hasil hitungan*/
CREATE TABLE tblHitung
(
atribut VARCHAR(20),
informasi VARCHAR(20),
jumlahdata INT,
diagnosademam INT,
diagnosaflu INT,
entropy DECIMAL(8,4),
gain DECIMAL(8,4)
);

DESC tblHitung;

SELECT COUNT(*) INTO @jumlahdata
FROM tblUAS14K10054;

SELECT COUNT(*) INTO @diagnosademam
FROM tblUAS14K10054
WHERE diagnosa = 'demam';

SELECT COUNT(*) INTO @diagnosaflu
FROM tblUAS14K10054
WHERE diagnosa = 'flu';

SELECT (-(@diagnosademam/@jumlahdata) * log2(@diagnosademam/@jumlahdata))
+
(-(@diagnosaflu/@jumlahdata)*log2(@diagnosaflu/@jumlahdata))
INTO @entropy;

SELECT @jumlahdata AS JUM_DATA,
@diagnosademam AS JAWAB_NO,
@diagnosaflu AS JAWAB_YES,
ROUND(@entropy, 4) AS ENTROPY;

INSERT INTO tblHitung(atribut, jumlahdata, diagnosademam, diagnosaflu, entropy) VALUES
('TOTAL DATA', @jumlahdata, @diagnosademam, @diagnosaflu, @entropy);

SELECT * FROM tblHitung;

/*LANGKAH 3: melakukan proses untuk setiap atribut*/
/*LEMAS*/
INSERT INTO tblHitung(informasi, jumlahdata, diagnosademam, diagnosaflu)
	SELECT A.lemas AS LEMAS, COUNT(*) AS JUMLAH_DATA,
		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS B
		WHERE B.diagnosa = 'demam' AND B.lemas = A.lemas
  ) AS 'demam',

		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS C
		WHERE C.diagnosa = 'flu' AND C.lemas = A.lemas
  ) AS 'flu'
	FROM tblUAS14K10054 AS A
	GROUP BY A.lemas;

UPDATE tblHitung SET atribut = 'WINDY' WHERE atribut IS NULL;

/*SAKITKEPALA*/
INSERT INTO tblHitung(informasi, jumlahdata, diagnosademam, diagnosaflu)
	SELECT A.sakitkepala AS SAKITKEPALA, COUNT(*) AS JUMLAH_DATA,
		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS B
		WHERE B.diagnosa = 'demam' AND B.sakitkepala = A.sakitkepala
		) AS 'DEMAM',

		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS C
		WHERE C.diagnosa = 'flu' AND C.sakitkepala = A.sakitkepala
		) AS 'FLU'
	FROM tblUAS14K10054 AS A
	GROUP BY A.sakitkepala;

UPDATE tblHitung SET atribut = 'SAKITKEPALA' WHERE atribut IS NULL;

/*NYERI*/
INSERT INTO tblHitung(informasi, jumlahdata, diagnosademam, diagnosaflu)
	SELECT A.nyeri AS NYERI, COUNT(*) AS JUMLAH_DATA,
		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS B
		WHERE B.diagnosa = 'demam' AND B.nyeri = A.nyeri
  ) AS 'demam',

		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS C
		WHERE C.diagnosa = 'flu' AND C.nyeri = A.nyeri
  ) AS 'flu'
	FROM tblUAS14K10054 AS A
	GROUP BY A.nyeri;

UPDATE tblHitung SET atribut = 'NYERI' WHERE atribut IS NULL;

/*DEMAM*/
INSERT INTO tblHitung(informasi, jumlahdata, diagnosademam, diagnosaflu)
	SELECT A.demam AS DEMAM, COUNT(*) AS JUMLAH_DATA,
		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS B
		WHERE B.diagnosa = 'demam' AND B.demam = A.demam
  ) AS 'demam',

		(
		SELECT COUNT(*)
		FROM tblUAS14K10054 AS C
		WHERE C.diagnosa = 'flu' AND C.demam = A.demam
  ) AS 'flu'
	FROM tblUAS14K10054 AS A
	GROUP BY A.demam;

UPDATE tblHitung SET atribut = 'DEMAM' WHERE atribut IS NULL;

/*LANGKAH 4: menghitung entropy*/
UPDATE tblHitung SET entropy = (-(diagnosademam/jumlahdata) * log2(diagnosademam/jumlahdata))
+
(-(diagnosaflu/jumlahdata) * log2(diagnosaflu/jumlahdata));

UPDATE tblHitung SET entropy = 0 WHERE entropy IS NULL;

SELECT * FROM tblHitung;

/*LANGKAH 5: menghitung nilai gain*/
DROP TABLE IF EXISTS tblTampung;
CREATE TEMPORARY TABLE tblTampung
(
atribut VARCHAR(20),
gain DECIMAL(4, 8)
);

INSERT INTO tblTampung(atribut, gain)
SELECT atribut, @entropy -
SUM((jumlahdata/@jumlahdata) * entropy) AS GAIN
FROM tblHitung
GROUP BY atribut;

SELECT * FROM tblTampung;

UPDATE tblHitung SET GAIN =
	(
	SELECT gain
	FROM tblTampung
	WHERE atribut = tblHitung.atribut
	);

SELECT * FROM tblHitung;
