DROP DATABASE IF EXISTS dbC45;
CREATE DATABASE dbC45;
USE dbC45;

CREATE TABLE tblC45 (
    no_pasien VARCHAR(10),
    demam VARCHAR(10),
    sakit_kepala VARCHAR(10),
    nyeri VARCHAR(10),
    lemas VARCHAR(10),
    kelelahan VARCHAR(10),
    hidung_tersumbat VARCHAR(10),
    bersin VARCHAR(10),
    sakit_tenggorokan VARCHAR(10),
    sulit_bernafas VARCHAR(10),
    diagnosa VARCHAR(10)
);

LOAD DATA LOCAL INFILE 'c45.csv'
INTO TABLE tblC45
FIELDS TERMINATED BY ';'
ENCLOSED BY ''''
IGNORE 1 LINES;

SELECT * FROM tblC45;

CREATE TABLE tblHitung (
    atribut VARCHAR(20),
    informasi VARCHAR(20),
    jumlahdata INT,
    diagnosa_demam INT,
    diagnosa_flu INT,
    entropy DECIMAL(8,4),
    gain DECIMAL(8,4)
);

DESC tblHitung;

SELECT COUNT(*) INTO @jumlahdata
FROM tblC45;

SELECT COUNT(*) INTO @diagnosa_demam
FROM tblC45
WHERE diagnosa = 'Demam';

SELECT COUNT(*) INTO @diagnosa_flu
FROM tblC45
WHERE diagnosa = 'Flu';

SELECT (-(@diagnosa_demam/@jumlahdata) * log2(@diagnosa_demam/@jumlahdata)) + (-(@diagnosa_flu/@jumlahdata) * log2(@diagnosa_flu/@jumlahdata))
INTO @entropy;

SELECT @jumlahdata AS JUM_DATA, @diagnosa_demam AS DIAGNOSA_DEMAM, @diagnosa_flu AS DIAGNOSA_FLU,
ROUND(@entropy, 4) AS ENTROPY;

INSERT INTO tblHitung(atribut, jumlahdata, diagnosa_demam, diagnosa_flu, entropy) VALUES
('TOTAL DATA', @jumlahdata, @diagnosa_demam, @diagnosa_flu, @entropy);

SELECT * FROM tblHitung;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.demam AS DEMAM, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.demam = A.demam
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.demam = A.demam
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.demam;

UPDATE tblHitung SET atribut = 'DEMAM' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.sakit_kepala AS SAKIT_KEPALA, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.sakit_kepala = A.sakit_kepala
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.sakit_kepala = A.sakit_kepala
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.sakit_kepala;

UPDATE tblHitung SET atribut = 'SAKIT KEPALA' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.nyeri AS NYERI, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.nyeri = A.nyeri
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.nyeri = A.nyeri
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.nyeri;

UPDATE tblHitung SET atribut = 'NYERI' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.lemas AS LEMAS, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.lemas = A.lemas
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.lemas = A.lemas
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.lemas;

UPDATE tblHitung SET atribut = 'LEMAS' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.kelelahan AS KELELAHAN, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.kelelahan = A.kelelahan
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.kelelahan = A.kelelahan
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.kelelahan;

UPDATE tblHitung SET atribut = 'KELELAHAN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.hidung_tersumbat AS HIDUNG_TERSUMBAT, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.hidung_tersumbat = A.hidung_tersumbat
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.hidung_tersumbat = A.hidung_tersumbat
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.hidung_tersumbat;

UPDATE tblHitung SET atribut = 'HIDUNG TERSUMBAT' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.bersin AS BERSIN, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.bersin = A.bersin
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.bersin = A.bersin
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.bersin;

UPDATE tblHitung SET atribut = 'BERSIN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.sakit_tenggorokan AS SAKIT_TENGGOROKAN, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.sakit_tenggorokan = A.sakit_tenggorokan
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.sakit_tenggorokan = A.sakit_tenggorokan
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.sakit_tenggorokan;

UPDATE tblHitung SET atribut = 'SAKIT TENGGOROKAN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
	SELECT A.sulit_bernafas AS SULIT_BERNAFAS, COUNT(*) AS JUMLAH_DATA, (
		SELECT COUNT(*)
		FROM tblC45 AS B
		WHERE B.diagnosa = 'Demam' AND B.sulit_bernafas = A.sulit_bernafas
	) AS 'DEMAM', (
		SELECT COUNT(*)
		FROM tblC45 AS C
		WHERE C.diagnosa = 'Flu' AND C.sulit_bernafas = A.sulit_bernafas
	) AS 'FLU'
	FROM tblC45 AS A
	GROUP BY A.sulit_bernafas;

UPDATE tblHitung SET atribut = 'SULIT BERNAFAS' WHERE atribut IS NULL;

UPDATE tblHitung SET entropy = (-(diagnosa_demam/jumlahdata) * log2(diagnosa_demam/jumlahdata)) + (-(diagnosa_flu/jumlahdata) * log2(diagnosa_flu/jumlahdata));

UPDATE tblHitung SET entropy = 0 WHERE entropy IS NULL;

SELECT * FROM tblHitung;

DROP TABLE IF EXISTS tblTampung;
CREATE TEMPORARY TABLE tblTampung (
    atribut VARCHAR(20),
    gain DECIMAL(8, 4)
);

INSERT INTO tblTampung(atribut, gain)
SELECT atribut, @entropy - SUM((jumlahdata/@jumlahdata) * entropy) AS GAIN
FROM tblHitung
GROUP BY atribut;

SELECT * FROM tblTampung;

UPDATE tblHitung SET GAIN = (
	SELECT gain
	FROM tblTampung
	WHERE atribut = tblHitung.atribut
);

SELECT * FROM tblHitung;

----- Iterasi 2 -----

TRUNCATE TABLE tblHitung;

SELECT COUNT(*) INTO @jumlahdata FROM tblC45 WHERE demam = 'Parah';

SELECT COUNT(*) INTO @diagnosa_demam FROM tblC45 WHERE diagnosa = 'Demam' AND demam = 'Parah';

SELECT COUNT(*) INTO @diagnosa_flu FROM tblC45 WHERE diagnosa = 'Flu' AND demam = 'Parah';

SELECT (-(@diagnosa_demam/@jumlahdata) * log2(@diagnosa_demam/@jumlahdata)) + (-(@diagnosa_flu/@jumlahdata) * log2(@diagnosa_flu/@jumlahdata)) INTO @entropy;

SELECT @jumlahdata AS JUM_DATA, @diagnosa_demam AS DIAGNOSA_DEMAM, @diagnosa_flu AS DIAGNOSA_FLU, ROUND(@entropy,4) AS ENTROPY;

INSERT INTO tblHitung(atribut, jumlahdata, diagnosa_demam, diagnosa_flu, entropy) VALUES ('TOTAL DATA', @jumlahdata, @diagnosa_demam, @diagnosa_flu, @entropy);
SELECT * FROM tblHitung;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.sakit_kepala AS SAKIT_KEPALA, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.sakit_kepala = A.sakit_kepala AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.sakit_kepala = A.sakit_kepala AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY sakit_kepala;

UPDATE tblHitung SET atribut = 'SAKIT KEPALA' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.nyeri AS NYERI, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.nyeri = A.nyeri AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.nyeri = A.nyeri AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY nyeri;

UPDATE tblHitung SET atribut = 'NYERI' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.lemas AS LEMAS, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.lemas = A.lemas AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.lemas = A.lemas AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY lemas;

UPDATE tblHitung SET atribut = 'LEMAS' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.kelelahan AS KELELAHAN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.kelelahan = A.kelelahan AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.kelelahan = A.kelelahan AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY kelelahan;

UPDATE tblHitung SET atribut = 'KELELAHAN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.hidung_tersumbat AS HIDUNG_TERSUMBAT, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.hidung_tersumbat = A.hidung_tersumbat AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.hidung_tersumbat = A.hidung_tersumbat AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY hidung_tersumbat;

UPDATE tblHitung SET atribut = 'HIDUNG TERSUMBAT' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.bersin AS BERSIN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.bersin = A.bersin AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.bersin = A.bersin AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY bersin;

UPDATE tblHitung SET atribut = 'BERSIN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.sakit_tenggorokan AS SAKIT_TENGGOROKAN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.sakit_tenggorokan = A.sakit_tenggorokan AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.sakit_tenggorokan = A.sakit_tenggorokan AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY sakit_tenggorokan;

UPDATE tblHitung SET atribut = 'SAKIT TENGGOROKAN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.sulit_bernafas AS SULIT_BERNAFAS, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.sulit_bernafas = A.sulit_bernafas AND demam = 'Parah'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.sulit_bernafas = A.sulit_bernafas AND demam = 'Parah'
    ) AS 'YES'
    FROM tblC45 AS A WHERE demam = 'Parah' GROUP BY sulit_bernafas;

UPDATE tblHitung SET atribut = 'SULIT BERNAFAS' WHERE atribut IS NULL;

UPDATE tblHitung SET entropy = (-(diagnosa_demam/jumlahdata) * log2(diagnosa_demam/jumlahdata)) + (-(diagnosa_flu/jumlahdata) * log2(diagnosa_flu/jumlahdata));

UPDATE tblHitung SET entropy = 0 WHERE entropy IS NULL;

SELECT * FROM tblHitung;

DROP TABLE IF EXISTS tblTampung;
CREATE TEMPORARY TABLE tblTampung (
    atribut VARCHAR(20),
    gain decimal(8,4)
);

INSERT INTO tblTampung(atribut, gain)
SELECT atribut, @entropy - SUM((jumlahdata/@jumlahdata) * entropy) AS GAIN FROM tblHitung GROUP BY atribut;

SELECT * FROM tblTampung;

UPDATE tblHitung SET GAIN = (
    SELECT gain
    FROM tblTampung
    WHERE atribut = tblHitung.atribut
);

SELECT * FROM tblHitung;

----- Iterasi 3 -----

TRUNCATE TABLE tblHitung;

SELECT COUNT(*) INTO @jumlahdata FROM tblC45 WHERE sulit_bernafas = 'Ringan';

SELECT COUNT(*) INTO @diagnosa_demam FROM tblC45 WHERE diagnosa = 'Demam' AND sulit_bernafas = 'Ringan';

SELECT COUNT(*) INTO @diagnosa_flu FROM tblC45 WHERE diagnosa = 'Flu' AND sulit_bernafas = 'Ringan';

SELECT (-(@diagnosa_demam/@jumlahdata) * log2(@diagnosa_demam/@jumlahdata)) + (-(@diagnosa_flu/@jumlahdata) * log2(@diagnosa_flu/@jumlahdata)) INTO @entropy;

SELECT @jumlahdata AS JUM_DATA, @diagnosa_demam AS DIAGNOSA_DEMAM, @diagnosa_flu AS DIAGNOSA_FLU, ROUND(@entropy,4) AS ENTROPY;

INSERT INTO tblHitung(atribut, jumlahdata, diagnosa_demam, diagnosa_flu, entropy) VALUES ('TOTAL DATA', @jumlahdata, @diagnosa_demam, @diagnosa_flu, @entropy);
SELECT * FROM tblHitung;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.demam AS DEMAM, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.demam = A.demam AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.demam = A.demam AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY demam;

UPDATE tblHitung SET atribut = 'SULIT BERNAFAS' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.sakit_kepala AS SAKIT_KEPALA, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.sakit_kepala = A.sakit_kepala AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.sakit_kepala = A.sakit_kepala AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY sakit_kepala;

UPDATE tblHitung SET atribut = 'SAKIT KEPALA' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.nyeri AS NYERI, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.nyeri = A.nyeri AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.nyeri = A.nyeri AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY nyeri;

UPDATE tblHitung SET atribut = 'NYERI' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.lemas AS LEMAS, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.lemas = A.lemas AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.lemas = A.lemas AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY lemas;

UPDATE tblHitung SET atribut = 'LEMAS' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.kelelahan AS KELELAHAN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.kelelahan = A.kelelahan AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.kelelahan = A.kelelahan AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY kelelahan;

UPDATE tblHitung SET atribut = 'KELELAHAN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.hidung_tersumbat AS HIDUNG_TERSUMBAT, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.hidung_tersumbat = A.hidung_tersumbat AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.hidung_tersumbat = A.hidung_tersumbat AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY hidung_tersumbat;

UPDATE tblHitung SET atribut = 'HIDUNG TERSUMBAT' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.bersin AS BERSIN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.bersin = A.bersin AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.bersin = A.bersin AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY bersin;

UPDATE tblHitung SET atribut = 'BERSIN' WHERE atribut IS NULL;

INSERT INTO tblHitung(informasi, jumlahdata, diagnosa_demam, diagnosa_flu)
    SELECT A.sakit_tenggorokan AS SAKIT_TENGGOROKAN, COUNT(*) AS JUMLAH_DATA, (
        SELECT COUNT(*)
        FROM tblC45 AS B
        WHERE B.diagnosa = 'Demam' AND B.sakit_tenggorokan = A.sakit_tenggorokan AND sulit_bernafas = 'Ringan'
    ) AS 'NO', (
        SELECT COUNT(*)
        FROM tblC45 AS C
        WHERE C.diagnosa = 'Flu' AND C.sakit_tenggorokan = A.sakit_tenggorokan AND sulit_bernafas = 'Ringan'
    ) AS 'YES'
    FROM tblC45 AS A WHERE sulit_bernafas = 'Ringan' GROUP BY sakit_tenggorokan;

UPDATE tblHitung SET atribut = 'SAKIT TENGGOROKAN' WHERE atribut IS NULL;

UPDATE tblHitung SET entropy = (-(diagnosa_demam/jumlahdata) * log2(diagnosa_demam/jumlahdata)) + (-(diagnosa_flu/jumlahdata) * log2(diagnosa_flu/jumlahdata));

UPDATE tblHitung SET entropy = 0 WHERE entropy IS NULL;

SELECT * FROM tblHitung;

DROP TABLE IF EXISTS tblTampung;
CREATE TEMPORARY TABLE tblTampung (
    atribut VARCHAR(20),
    gain decimal(8,4)
);

INSERT INTO tblTampung(atribut, gain)
SELECT atribut, @entropy - SUM((jumlahdata/@jumlahdata) * entropy) AS GAIN FROM tblHitung GROUP BY atribut;

SELECT * FROM tblTampung;

UPDATE tblHitung SET GAIN = (
    SELECT gain
    FROM tblTampung
    WHERE atribut = tblHitung.atribut
);

SELECT * FROM tblHitung;

/*
Kesimpulan

Iterasi 1 menghasilkan entropy 0.9975 untuk semua data serta memberi informasi tentang
tidak, ringan, parahnya penyakit pasien tersebut, menghasilkan gain 0.9975 ke seluruh data
dan juga mendiagnosa pasien tersebut serta mengelompokkannya berdasarkan jenis penyakitnya.

Iterasi 2 mengetest data berdasarkan penyakit demam yg parah dan meproses semua data
yg lain, entropy NULL dikarenakan tidak adanya diagnosa demam di dalam data iterasi 2
sehingga data yang lain juga tidak menghasilkan gain / data bernilai NULL.

Iterasi 3 mengetest data berdasarkan penyakit demam yg parah dan meproses semua data
yg lain dan menghasilkan entropy sebesar 0.7219 untuk 5 data yg terdiri dari 4 demam dan 1 flu
serta memberikan gain ke seluruh data sebesar 0.7219
*/